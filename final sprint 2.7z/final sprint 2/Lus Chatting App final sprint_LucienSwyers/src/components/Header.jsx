// This is the header

import React from "react";
import { Link } from "react-router-dom";
import CreatePost from "./CreatePost";

const Header = () => {
  return (
    <div id="Header">
      <h2 id="JNC">Lu's Chatting!!</h2>
      {/* Search bar that does nothing...  */}
      <input type="text" placeholder="Search for a friend . . ." id="Search" />

      {/* Links to different sections of the app  */}
      <Link id="MyFeed" to="/Main">
        My Feed
      </Link>
      <Link id="SignOutLink" to="/">
        Sign Out
      </Link>
    </div>
  );
};

export default Header;

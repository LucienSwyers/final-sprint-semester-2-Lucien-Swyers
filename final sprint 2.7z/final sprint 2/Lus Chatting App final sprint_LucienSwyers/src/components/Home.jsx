import React from "react";
import Login from "./Login";
import Header from "./Header";

// I created the home component but alot of this confused me since I was working alone..//

const Home = () => {
  return (
    <div className="Home">
      <>
        <Login />
      </>
    </div>
  );
};

export default Home;

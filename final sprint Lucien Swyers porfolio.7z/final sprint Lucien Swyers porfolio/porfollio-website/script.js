//Name:Lucien Swyers, Porfollio project for semester2 final sprint for Mr Noman
// i only did a basic idea of what would eventually lead into a bigger porfolli page that i could eventually expand with the school career.

// Dynamically load project examples
document.addEventListener("DOMContentLoaded", () => {
    const projects = [
      {
        title: "Dog Image Gallery",
        description: "A dynamic app showcasing dog breeds using the Dog CEO API.",
        link: "https://plus.unsplash.com/premium_photo-1666229410352-c4686b71cea2?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8ZG9nc3xlbnwwfHwwfHx8MA%3D%3D"
      },
      {
        title: "post related Basic chat app",
        description: "A chat app where you make a profile and post about anything.",
        link: "https://images.unsplash.com/photo-1523837157348-ffbdaccfc7de?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y2hhdCUyMHR5cGUlMjBsb2dvc3xlbnwwfHwwfHx8MA%3D%3D"
      },
      {
        title: "React Portfolio",
        description: "My personal React portfolio showcasing various skills and projects.",
        link: "https://images.unsplash.com/photo-1594904351111-a072f80b1a71?q=80&w=1935&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
      }
    ];
  
    const projectGrid = document.querySelector(".project-grid");
  
    projects.forEach(project => {
      const projectCard = document.createElement("div");
      projectCard.classList.add("project-card");
  
      projectCard.innerHTML = `
        <h3>${project.title}</h3>
        <p>${project.description}</p>
        <a href="${project.link}" target="_blank">View Project</a>
      `;
  
      projectGrid.appendChild(projectCard);
    });
  });
  
  // Handle Contact Form Submission
  document.getElementById("contact-form").addEventListener("submit", event => {
    event.preventDefault();
    alert("Thank you for reaching out! I'll get back to you soon.");
  });
  